$(document).ready(function(){
    alert('das');
});
